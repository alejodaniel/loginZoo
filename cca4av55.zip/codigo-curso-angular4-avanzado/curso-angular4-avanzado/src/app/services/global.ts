export var GLOBAL = {
	url: 'http://localhost:3789/api/'
}