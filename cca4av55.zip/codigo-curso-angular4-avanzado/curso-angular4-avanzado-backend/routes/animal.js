'use strict'

var express = require('express');
var AnimalContoller = require('../controllers/animal');

var api = express.Router();
var md_auth = require('../middlewares/authenticated'); 
var md_admin = require('../middlewares/is_admin'); 

var multipart = require('connect-multiparty');
var md_upload = multipart({ uploadDir: './uploads/animals' });

api.get('/pruebas-animales', md_auth.ensureAuth, AnimalContoller.pruebas);
api.post('/animal', [md_auth.ensureAuth, md_admin.isAdmin], AnimalContoller.saveAnimal);
api.get('/animals', AnimalContoller.getAnimals);
api.get('/animal/:id', AnimalContoller.getAnimal);
api.put('/animal/:id', [md_auth.ensureAuth, md_admin.isAdmin], AnimalContoller.updateAnimal);
api.post('/upload-image-animal/:id', [md_auth.ensureAuth, md_admin.isAdmin, md_upload], AnimalContoller.uploadImage);
api.get('/get-image-animal/:imageFile', AnimalContoller.getImageFile);
api.delete('/animal/:id', [md_auth.ensureAuth, md_admin.isAdmin], AnimalContoller.deleteAnimal);

module.exports = api;